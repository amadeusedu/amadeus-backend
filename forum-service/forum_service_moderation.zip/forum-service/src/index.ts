
import express from 'express';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

const {
  PGHOST = 'localhost',
  PGPORT = '5432',
  PGUSER = 'amadeus',
  PGPASSWORD = 'password',
  PGDATABASE = 'notification_forum',
  PORT = '3003'
} = process.env;

const pool = new Pool({
  host: PGHOST,
  port: parseInt(PGPORT, 10),
  user: PGUSER,
  password: PGPASSWORD,
  database: PGDATABASE
});

const app = express();
app.use(express.json());

/**
 * POST /threads
 * Body: { user_id, title, body, course_id? }
 */
app.post('/threads', async (req, res) => {
  const { user_id, title, body, course_id } = req.body;
  if (!user_id || !title || !body) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = uuidv4();
  try {
    await pool.query(
      `INSERT INTO threads (id, user_id, course_id, title, body, status, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, 'OPEN', NOW(), NOW())`,
      [id, user_id, course_id, title, body]
    );
    res.status(201).json({ id });
  } catch (err) {
    console.error('Create thread failed', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

/**
 * POST /threads/:id/reply
 * Body: { user_id, body, parent_post_id? }
 */
app.post('/threads/:id/reply', async (req, res) => {
  const thread_id = req.params.id;
  const { user_id, body: content, parent_post_id } = req.body;
  if (!user_id || !content) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = uuidv4();
  try {
    await pool.query(
      `INSERT INTO posts (id, thread_id, parent_post_id, user_id, body, status, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, 'VISIBLE', NOW(), NOW())`,
      [id, thread_id, parent_post_id, user_id, content]
    );
    res.status(201).json({ id });
  } catch (err) {
    console.error('Reply failed', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

/**
 * GET /threads/:id
 * Query param: ?limit=20&offset=0
 * Returns thread + posts
 */
app.get('/threads/:id', async (req, res) => {
  const thread_id = req.params.id;
  const limit = parseInt((req.query.limit as string) || '20', 10);
  const offset = parseInt((req.query.offset as string) || '0', 10);

  try {
    const threadRes = await pool.query('SELECT * FROM threads WHERE id = $1', [thread_id]);
    if (threadRes.rowCount === 0) {
      return res.status(404).json({ error: 'Thread not found' });
    }
    const postsRes = await pool.query(
      `SELECT * FROM posts
       WHERE thread_id = $1 AND status = 'VISIBLE'
       ORDER BY created_at ASC
       LIMIT $2 OFFSET $3`,
      [thread_id, limit, offset]
    );
    res.json({ thread: threadRes.rows[0], posts: postsRes.rows });
  } catch (err) {
    console.error('Fetch thread failed', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

app.get('/health', (_req, res) => res.send('ok'));

app.listen(parseInt(PORT, 10), () => {
  console.log(`Forum service listening on ${PORT}`);
});
