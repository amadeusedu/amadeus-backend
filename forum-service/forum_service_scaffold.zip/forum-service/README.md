
# Forum Service

Basic scaffold providing:

* `POST /threads` – create a thread
* `POST /threads/:id/reply` – add a reply (optionally nested via `parent_post_id`)
* `GET /threads/:id?limit=20&offset=0` – fetch thread plus visible posts

## Run locally

```bash
npm install
npm run dev           # API on :3003
```

### Env vars

```
PGHOST=localhost
PGPORT=5432
PGUSER=amadeus
PGPASSWORD=password
PGDATABASE=notification_forum
PORT=3003
```

Tables must exist (see `docs/architecture/notification_forum_design.md`).

## Docker

```bash
docker build -t forum-service .
docker run -p 3003:3003   -e PGHOST=host.docker.internal ... forum-service
```
