
# Terraform – Notification & Forum Infra (Dev B Week 6)

This module provisions:

1. **PostgreSQL (Amazon RDS)** instance **`notification_forum`** for Notifications & Forum tables  
2. **Redis (ElastiCache)** replication group **`notif-email-queue`** for the outgoing email job queue  
3. **S3 bucket** **`amadeus-email-templates`** (versioned, encrypted) for storing MJML/HTML templates

> **Location:** `infra/db/` in the monorepo

## Usage

```hcl
module "notif_forum_infra" {
  source              = "./infra/db"
  aws_region          = "ap-southeast-2"
  vpc_id              = "vpc-123456"
  private_subnet_ids  = ["subnet-abc", "subnet-def"]
  app_subnet_cidrs    = ["10.0.10.0/24", "10.0.11.0/24"]

  db_password         = var.db_master_password
}
```

After `terraform apply`, connect to Postgres and run your migration tool
(Prisma/Flyway) to create the **notifications**, **threads**, **posts**, and
**moderation_flags** tables as defined in
`docs/architecture/notification_forum_design.md`.

## Outputs

* `rds_endpoint` – DB host for application services  
* `redis_primary_endpoint` – Redis host for email queue  
* `email_templates_bucket` – S3 bucket name
