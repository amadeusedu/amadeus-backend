# User‑Profile & Policy‑Engine Architecture (v1)

**Generated:** 2025-06-19

---

## 1  Overview

This document details the internal architecture for the two new services that sit alongside **Auth**:

| Service | Responsibility |
|---------|----------------|
| **User‑Profile** | CRUD for personal information, subjects, avatars, preferences. Publishes “profile.updated” events so other services can react. |
| **Policy‑Engine** | Centralised authorisation oracle—evaluates “can *subject* do *action* on *resource*?” queries for all domains. |

They share the `identity` database but run as **separate containers** behind the gateway.

---

## 2  User‑Profile Service

```mermaid
flowchart TD
  subgraph Profile Service
    direction TB
    API[HTTP API\n(REST / GraphQL)]
    Logic[Domain Logic]
    Cache((Redis)]
    DB[(PostgreSQL: profiles)]
    Events[[SNS/SQS "profile.updated"]]
  end
  API -->|DTOs| Logic
  Logic --> Cache
  Logic --> DB
  Logic --> Events
  Cache --> DB
```

### Components

| Component | Tech | Notes |
|-----------|------|-------|
| API Layer | FastAPI (Python) or NestJS (TS) | Auto‑generated routes from OpenAPI/GraphQL |
| Domain Logic | Service + Repository classes | Handles validation, file‑upload signature generation, etc. |
| Persistence | PostgreSQL `profiles` table | Same cluster as Auth. |
| Cache | Redis | `me` lookups & avatars; TTL 10 min. |
| Events | SNS topic `profile.updated` | Fan‑out to Notification, Analytics. |

---

## 3  Policy‑Engine Service

```mermaid
flowchart TD
  Caller[[Any Service]] --> HTTPAPI
  HTTPAPI[Policy REST/GraphQL]
  HTTPAPI --> OPA[OPA Evaluator\n(sidecar or library)]
  OPA -->|decision| HTTPAPI
  OPA --> PolicyStore[(PostgreSQL: policies)]
  OPA --> Cache((In‑mem LRU))
```

### Key decisions

* **Open Policy Agent (OPA)** embedded via Go WASM for <1 ms average eval.
* Policies stored in `policies` table; hot rules cached in‑mem.
* Sidecar or library mode selectable via env var to simplify local dev.
* CI runs rego unit tests to catch privilege‑escalation regressions.

---

## 4  GraphQL Schema (draft)

```graphql
schema {
  query: Query
  mutation: Mutation
}

type Query {
  """Return profile for currently authenticated user"""
  me: Profile!
  """Fetch arbitrary profile"""
  profile(id: ID!): Profile
  """List roles attached to a user"""
  roles(userId: ID!): [Role!]!
}

type Mutation {
  """Partial update of own profile"""
  updateProfile(input: UpdateProfileInput!): Profile!
  """Ask Policy Engine for decision"""
  authorize(input: AuthorizeInput!): PolicyDecision!
}

"""User profile object"""
type Profile {
  userId: ID!
  fullName: String!
  avatarUrl: String
  vceSubjects: [String!]
  bio: String
  updatedAt: String!
}

"""System role enumeration"""
enum Role {
  STUDENT
  TUTOR
  ADMIN
}

input UpdateProfileInput {
  fullName: String
  avatarUrl: String
  vceSubjects: [String!]
  bio: String
}

input AuthorizeInput {
  subject: String!
  action: String!
  resource: String!
  context: JSON
}

type PolicyDecision {
  allow: Boolean!
  reason: String
}

scalar JSON
```

Copy the above into `profile-policy.graphql` (already generated).

---

## 5  API Contract Status

* **REST** — endpoints already frozen in `identity-access.yaml` (`/profiles/*`, `/policy/decide`).
* **GraphQL** — SDL exported to `profile-policy.graphql`.

---

## 6  Deployment & Ops

* **Images** built via GitHub Actions → pushed to ECR.
* **Helm charts** co‑locate both services in the `identity` namespace.
* **OPA bundles** delivered by the chart; hot‑reloaded on ConfigMap change.
* **Metrics**:  
  * Profile: `profile.get.latency`, `profile.update.error_rate`  
  * Policy: `opa.evaluate.latency`, `policy.store.misses`  
* **Alerts:** 99th pctl > 100 ms or deny decisions > baseline.

---