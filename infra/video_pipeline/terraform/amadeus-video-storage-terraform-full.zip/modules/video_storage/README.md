# Video Storage Terraform Module

Provisions a private S3 bucket and CloudFront distribution to store and serve
Amadeus Education course videos.

## Usage

```hcl
module "video_storage" {
  source  = "../../modules/video_storage"

  project     = "amadeus"
  environment = "dev"

  force_destroy = true   # dev only
  tags = {
    Owner = "DevB"
    Repo  = "amadeus-backend"
  }
}
```

Run:

```bash
terraform init
terraform apply -var='region=ap-southeast-2'
```
