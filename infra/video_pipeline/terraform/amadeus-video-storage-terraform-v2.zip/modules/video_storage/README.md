# Video Storage Module (v2)

Adds a **CloudFront distribution** fronting the private S3 bucket and a
**stub invalidation** resource you can extend later (CI/CD).

## Quick test

```bash
cd examples/dev
terraform init
terraform apply -var='region=ap-southeast-2'
```

The output `cloudfront_domain` should return `*.cloudfront.net`. Visit it —
you will see 403 until signed URLs are used.

## Cache Invalidation

For production you should replace the `null_resource.stub_invalidation`
with an **aws_cloudfront_distribution_invalidation** triggered by CI after
video uploads. For now it logs the intended paths.

Generated 2025-06-22T04:57:38Z
