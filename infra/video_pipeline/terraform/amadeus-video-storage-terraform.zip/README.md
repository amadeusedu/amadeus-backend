# Amadeus Terraform Infrastructure

This repository contains the Terraform module for **Video Storage & CDN**.

## Directory structure
```
modules/video_storage   # reusable module
examples/dev            # sample usage
```

## Quick start (dev)
```bash
cd examples/dev
terraform init
terraform plan -var='region=ap-southeast-2'
terraform apply   # creates bucket + CDN
```

_Generated 2025-06-22_
