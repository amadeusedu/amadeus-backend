# Terraform Module: video_storage

Provisions an S3 bucket **and** a stub CloudFront distribution for Amadeus Education video assets.

## Features
* KMS‑encrypted, versioned S3 bucket
* Public access blocked
* Lifecycle tiering → INTELLIGENT_TIERING after 30 days, delete at 365 days
* CloudFront distribution with Origin Access Control (OAC) — _bucket stays private_
* Minimal cache behaviour (1 hour default TTL) — tune later
* Taggable, force‑destroy toggle (useful in dev)

## Usage
```hcl
module "video_storage" {
  source      = "github.com/amadeus-edu/terraform-modules//video_storage?ref=v0.1.0"
  bucket_name = "ae-video-prod-${data.aws_caller_identity.this.account_id}"
  kms_key_id  = aws_kms_key.video_kms.key_id
  tags = {
    Environment = "prod"
  }
}
```

## Outputs
* `bucket_id`, `bucket_arn`
* `cloudfront_domain`, `cloudfront_id`

_Generated 2025-06-22_
