
import express from 'express';
import { Pool } from 'pg';
import Redis from 'ioredis';
import { v4 as uuidv4 } from 'uuid';

const {
  PGHOST = 'localhost',
  PGPORT = '5432',
  PGUSER = 'amadeus',
  PGPASSWORD = 'password',
  PGDATABASE = 'notification_forum',
  REDIS_HOST = 'localhost',
  REDIS_PORT = '6379',
  PORT = '3002'
} = process.env;

const pool = new Pool({
  host: PGHOST,
  port: parseInt(PGPORT, 10),
  user: PGUSER,
  password: PGPASSWORD,
  database: PGDATABASE
});

const redis = new Redis(parseInt(REDIS_PORT, 10), REDIS_HOST);

const app = express();
app.use(express.json());

/**
 * POST /notifications
 * Body: { user_id: uuid, type: string, channel: string, title: string, body: string }
 */
app.post('/notifications', async (req, res) => {
  const { user_id, type, channel = 'IN_APP', title, body } = req.body;

  if (!user_id || !title || !body) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = uuidv4();
  const status = channel === 'EMAIL' ? 'QUEUED' : 'SENT'; // if email, queue for sending
  const created_at = new Date().toISOString();

  try {
    await pool.query(
      `INSERT INTO notifications (id, user_id, type, channel, title, body, status, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [id, user_id, type, channel, title, body, status, created_at]
    );

    if (channel === 'EMAIL') {
      // push job onto Redis queue
      const job = JSON.stringify({
        notification_id: id,
        template_id: 'generic',
        to_user_id: user_id,
        subject: title,
        body
      });
      await redis.lpush('email_queue', job);
    }

    res.status(201).json({ id, status });
  } catch (err) {
    console.error('Error inserting notification', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/health', (_req, res) => res.send('ok'));

app.listen(parseInt(PORT, 10), () => {
  console.log(`Notification service listening on ${PORT}`);
});
