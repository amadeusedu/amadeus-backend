
import Redis from 'ioredis';
import { renderEmailTemplate } from './templateEngine';
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import sgMail from '@sendgrid/mail';
import { Pool } from 'pg';

const {
  REDIS_HOST = 'localhost',
  REDIS_PORT = '6379',
  SENDGRID_API_KEY,
  SES_REGION = 'ap-southeast-2',
  FROM_EMAIL = 'no-reply@amadeus-edu.com',
  PGHOST = 'localhost',
  PGPORT = '5432',
  PGUSER = 'amadeus',
  PGPASSWORD = 'password',
  PGDATABASE = 'notification_forum'
} = process.env;

const redis = new Redis(parseInt(REDIS_PORT, 10), REDIS_HOST);

const ses = new SESClient({ region: SES_REGION });
if (SENDGRID_API_KEY) {
  sgMail.setApiKey(SENDGRID_API_KEY);
}

const pool = new Pool({
  host: PGHOST,
  port: parseInt(PGPORT, 10),
  user: PGUSER,
  password: PGPASSWORD,
  database: PGDATABASE
});

console.log('Notification email worker started – polling email_queue');

async function markSent(notificationId: string) {
  await pool.query(
    'UPDATE notifications SET status = $1, sent_at = NOW() WHERE id = $2',
    ['SENT', notificationId]
  );
}

async function processJob(jobStr: string) {
  const job = JSON.parse(jobStr);
  console.log('[Worker] Processing email job:', job);

  const { html, subject } = await renderEmailTemplate(job.template_id, job.merge_vars || {});

  if (SENDGRID_API_KEY) {
    await sgMail.send({
      to: job.to,
      from: FROM_EMAIL,
      subject,
      html
    });
  } else {
    await ses.send(
      new SendEmailCommand({
        Destination: { ToAddresses: [job.to] },
        Message: {
          Body: { Html: { Data: html, Charset: 'UTF-8' } },
          Subject: { Data: subject, Charset: 'UTF-8' }
        },
        Source: FROM_EMAIL
      })
    );
  }

  await markSent(job.notification_id);
}

async function work() {
  while (true) {
    try {
      const result = await redis.brpop('email_queue', 0);
      if (result) {
        const [, jobStr] = result;
        try {
          await processJob(jobStr);
        } catch (err) {
          console.error('[Worker] Failed to process job', err);
          // Requeue or move to dead-letter list if needed
        }
      }
    } catch (err) {
      console.error('Worker error', err);
    }
  }
}

work();
