
# Notification Service (Base Scaffold)

*Language: TypeScript (Node 20)  
*Location:* `notification-service/`

## Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/notifications` | Store a notification & (if `channel=EMAIL`) push job onto Redis `email_queue` |
| `GET`  | `/health` | Liveness probe |

## Running locally

```bash
# install deps
npm install

# start dev server (requires Postgres & Redis running)
npm run dev

# start worker in another terminal
npm run worker
```

Environment variables (`.env` or shell):

```
PGHOST=localhost
PGPORT=5432
PGUSER=amadeus
PGPASSWORD=password
PGDATABASE=notification_forum
REDIS_HOST=localhost
REDIS_PORT=6379
PORT=3002
```

## Notes

* DB schema matches tables defined in `docs/architecture/notification_forum_design.md`.
* Email worker **only logs** the job; replace with SES/SendGrid integration later.
* Dockerfile supports multi‑stage build (final image ~80 MB).
