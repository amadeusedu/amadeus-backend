
import Redis from 'ioredis';

const {
  REDIS_HOST = 'localhost',
  REDIS_PORT = '6379'
} = process.env;

const redis = new Redis(parseInt(REDIS_PORT, 10), REDIS_HOST);

console.log('Notification email worker started – polling email_queue');

async function work() {
  while (true) {
    try {
      // BRPOP blocks until item available
      const result = await redis.brpop('email_queue', 0);
      if (result) {
        const [, jobStr] = result;
        const job = JSON.parse(jobStr);
        console.log('[Worker] Pretend‑send email job:', job);
        // In future: render MJML, call SES/SendGrid here
      }
    } catch (err) {
      console.error('Worker error', err);
    }
  }
}

work();
