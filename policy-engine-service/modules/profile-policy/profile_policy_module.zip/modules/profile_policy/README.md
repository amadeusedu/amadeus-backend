# Terraform Module – Profile & Policy Infrastructure

Provisions:

* `profiles` and `policies` tables in the shared PostgreSQL cluster
* Least‑privilege IAM roles for:
  * **Profile Service** (SNS publish, S3 avatar bucket, SecretsManager for DB creds)
  * **Policy Engine** (SecretsManager for DB creds)

## Usage

```hcl
module "profile_policy" {
  source                = "./modules/profile_policy"
  env                   = var.env           # dev / stage / prod
  db_host               = aws_db_instance.identity.endpoint
  db_port               = 5432
  db_admin_user         = var.pg_admin_user
  db_admin_pass         = var.pg_admin_pass
  db_secret_arn         = aws_secretsmanager_secret.db_creds.arn
  sns_topic_arn         = module.notifications.profile_topic_arn
  avatar_bucket_arn     = module.assets.avatars_bucket_arn
  assume_role_principal = "ecs-tasks.amazonaws.com"
}

output "profile_service_role" {
  value = module.profile_policy.profile_role_arn
}
```

## Outputs

| Name | Description |
|------|-------------|
| `profiles_table_name` | Fully‑qualified name of the **profiles** table |
| `policies_table_name` | Fully‑qualified name of the **policies** table |
| `profile_role_arn` | IAM role for the Profile micro‑service |
| `policy_role_arn` | IAM role for the Policy Engine |