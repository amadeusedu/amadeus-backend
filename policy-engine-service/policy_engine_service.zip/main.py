
from fastapi import FastAPI, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, String, Integer, JSON
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from typing import Optional
import fnmatch, os

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg2://app_user:password@localhost:5432/identity")

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()

class PolicyORM(Base):
    __tablename__ = "policies"
    id = Column(String, primary_key=True)
    subject = Column(String, nullable=False)
    action = Column(String, nullable=False)
    resource = Column(String, nullable=False)
    effect = Column(String, nullable=False)
    conditions = Column(JSON, nullable=True)
    priority = Column(Integer, nullable=False, default=100)

class DecisionRequest(BaseModel):
    subject: str = Field(..., example="user:123")
    action: str = Field(..., example="update")
    resource: str = Field(..., example="profile:123")
    context: Optional[dict] = None

class DecisionResponse(BaseModel):
    allow: bool
    reason: str

app = FastAPI(title="Amadeus Policy Engine", version="1.0.0")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def _match(pattern: str, value: str) -> bool:
    return fnmatch.fnmatchcase(value, pattern)

def evaluate_policy(req: DecisionRequest, db: Session) -> DecisionResponse:
    rules = db.query(PolicyORM).order_by(PolicyORM.priority).all()
    for rule in rules:
        if not _match(rule.subject, req.subject):
            continue
        if not _match(rule.action, req.action):
            continue
        if not _match(rule.resource, req.resource):
            continue
        return DecisionResponse(allow=rule.effect.upper() == "ALLOW", reason=f"Matched rule {rule.id}")
    return DecisionResponse(allow=False, reason="No matching rule → default DENY")

@app.post("/policy/decide", response_model=DecisionResponse)
def decide(req: DecisionRequest, db: Session = Depends(get_db)):
    resp = evaluate_policy(req, db)
    if not resp.allow:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=resp.reason)
    return resp

@app.get("/health")
def health():
    return {"status": "ok"}

@app.on_event("startup")
def create_tables():
    Base.metadata.create_all(bind=engine)
