
from fastapi import FastAPI, Depends, HTTPException, status, Header
from pydantic import BaseModel, Field
from typing import List, Optional
import os, httpx, uuid
from sqlalchemy import create_engine, Column, String, JSON, TIMESTAMP
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from jose import jwt, JWTError
from datetime import datetime

# -------------------------------------------------------------
# CONFIG
# -------------------------------------------------------------
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg2://app_user:password@localhost:5432/identity",
)
POLICY_ENGINE_URL = os.getenv(
    "POLICY_ENGINE_URL", "http://policy-engine:8001/policy/decide"
)
JWT_PUBLIC_KEY = os.getenv("JWT_PUBLIC_KEY", "")
ALGORITHM = "RS256"

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()

# -------------------------------------------------------------
# ORM MODELS
# -------------------------------------------------------------
class ProfileORM(Base):
    __tablename__ = "profiles"
    user_id = Column(String, primary_key=True)
    full_name = Column(String, nullable=False)
    avatar_url = Column(String)
    vce_subjects = Column(JSON)
    bio = Column(String)
    updated_at = Column(TIMESTAMP, default=datetime.utcnow, nullable=False)


class PolicyORM(Base):
    __tablename__ = "policies"
    id = Column(String, primary_key=True)
    subject = Column(String, nullable=False)
    action = Column(String, nullable=False)
    resource = Column(String, nullable=False)
    effect = Column(String, nullable=False)  # ALLOW / DENY
    conditions = Column(JSON)
    priority = Column(int, default=100, nullable=False)


# -------------------------------------------------------------
# DTOs
# -------------------------------------------------------------
class ProfileIn(BaseModel):
    full_name: Optional[str] = Field(None, example="Jane Doe")
    avatar_url: Optional[str] = None
    vce_subjects: Optional[List[str]] = None
    bio: Optional[str] = None


class ProfileOut(ProfileIn):
    user_id: str
    updated_at: datetime


# -------------------------------------------------------------
# FastAPI app
# -------------------------------------------------------------
app = FastAPI(title="Amadeus User Profile Service", version="1.2.0")


# -------------------------------------------------------------
# Dependencies
# -------------------------------------------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_user_id(authorization: str = Header(..., alias="Authorization")) -> str:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(
            token, JWT_PUBLIC_KEY, algorithms=[ALGORITHM], options={"verify_aud": False}
        )
        return payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Token validation failed")


# -------------------------------------------------------------
# Policy Engine helper
# -------------------------------------------------------------
async def authorize(subject: str, action: str, resource: str):
    payload = {"subject": subject, "action": action, "resource": resource}
    async with httpx.AsyncClient(timeout=5) as client:
        resp = await client.post(POLICY_ENGINE_URL, json=payload)
    if resp.status_code == 200:
        return
    if resp.status_code == 403:
        raise HTTPException(status_code=403, detail="Forbidden by policy")
    raise HTTPException(status_code=500, detail="Policy Engine error")


# -------------------------------------------------------------
# CRUD endpoints with policy checks
# -------------------------------------------------------------
@app.post("/profiles", response_model=ProfileOut, status_code=201)
async def create_profile(
    body: ProfileIn, db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)
):
    await authorize(subject=f"user:{user_id}", action="create", resource=f"profile:{user_id}")
    if db.get(ProfileORM, user_id):
        raise HTTPException(status_code=409, detail="Profile already exists")
    profile = ProfileORM(user_id=user_id, **body.dict(exclude_unset=True))
    db.add(profile)

    # Automatically seed owner-allow policy so the user can manage their own profile
    owner_policy = PolicyORM(
        id=str(uuid.uuid4()),
        subject=f"user:{user_id}",
        action="*",
        resource=f"profile:{user_id}",
        effect="ALLOW",
        priority=10,
    )
    db.add(owner_policy)
    db.commit()
    db.refresh(profile)
    return profile


@app.get("/profiles/me", response_model=ProfileOut)
async def read_own_profile(
    db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)
):
    await authorize(subject=f"user:{user_id}", action="read", resource=f"profile:{user_id}")
    profile = db.get(ProfileORM, user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile


@app.patch("/profiles/me", response_model=ProfileOut)
async def update_own_profile(
    body: ProfileIn, db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)
):
    await authorize(subject=f"user:{user_id}", action="update", resource=f"profile:{user_id}")
    profile = db.get(ProfileORM, user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    for k, v in body.dict(exclude_unset=True).items():
        setattr(profile, k, v)
    profile.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(profile)
    return profile


@app.delete("/profiles/me", status_code=204)
async def delete_own_profile(
    db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)
):
    await authorize(subject=f"user:{user_id}", action="delete", resource=f"profile:{user_id}")
    profile = db.get(ProfileORM, user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    db.delete(profile)
    db.commit()
    return


# ---------------- Admin operations ----------------
@app.get("/profiles/{target_id}", response_model=ProfileOut, tags=["admin"])
async def admin_read_profile(
    target_id: str, db: Session = Depends(get_db), caller_id: str = Depends(get_current_user_id)
):
    await authorize(subject=f"user:{caller_id}", action="read", resource=f"profile:{target_id}")
    profile = db.get(ProfileORM, target_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile


@app.delete("/profiles/{target_id}", status_code=204, tags=["admin"])
async def admin_delete_profile(
    target_id: str, db: Session = Depends(get_db), caller_id: str = Depends(get_current_user_id)
):
    await authorize(subject=f"user:{caller_id}", action="delete", resource=f"profile:{target_id}")
    profile = db.get(ProfileORM, target_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    db.delete(profile)
    db.commit()
    return


# -------------------------------------------------------------
# Start‑up: create tables in dev
# -------------------------------------------------------------
@app.on_event("startup")
def create_tables():
    Base.metadata.create_all(bind=engine)
