-- seed_policies.sql
-- Grant admins full access to all profiles & default deny everyone else
INSERT INTO policies (id, subject, action, resource, effect, priority)
VALUES
  (uuid_generate_v4(), 'role:ADMIN', '*', 'profile:*', 'ALLOW', 1),
  (uuid_generate_v4(), 'user:*', '*', 'profile:*', 'DENY', 100);
