from fastapi import FastAPI, Depends, HTTPException, status, Header
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid, os, httpx
from sqlalchemy import create_engine, Column, String, JSON, TIMESTAMP
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from jose import jwt, JWTError
from datetime import datetime

# -------------------------------------------------------------
# CONFIGURATION
# -------------------------------------------------------------
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg2://app_user:password@localhost:5432/identity")
POLICY_ENGINE_URL = os.getenv("POLICY_ENGINE_URL", "http://policy-engine:8001/policy/decide")
JWT_PUBLIC_KEY = os.getenv("JWT_PUBLIC_KEY", "")  # PEM or JWKS fetch in prod
ALGORITHM = "RS256"

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()

# -------------------------------------------------------------
# DATABASE MODEL
# -------------------------------------------------------------
class ProfileORM(Base):
    __tablename__ = "profiles"
    user_id = Column(String, primary_key=True)
    full_name = Column(String, nullable=False)
    avatar_url = Column(String, nullable=True)
    vce_subjects = Column(JSON, nullable=True)
    bio = Column(String, nullable=True)
    updated_at = Column(TIMESTAMP, nullable=False, default=datetime.utcnow)

# -------------------------------------------------------------
# Pydantic DTOs
# -------------------------------------------------------------
class ProfileIn(BaseModel):
    full_name: Optional[str] = Field(None, example="Jane Doe")
    avatar_url: Optional[str] = None
    vce_subjects: Optional[List[str]] = None
    bio: Optional[str] = None

class ProfileOut(ProfileIn):
    user_id: str
    updated_at: datetime

# -------------------------------------------------------------
# FastAPI app
# -------------------------------------------------------------
app = FastAPI(title="Amadeus User Profile Service", version="1.1.0")

# -------------------------------------------------------------
# DEPENDENCIES
# -------------------------------------------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_current_user_id(authorization: str = Header(..., alias="Authorization")) -> str:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token format")
    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, JWT_PUBLIC_KEY, algorithms=[ALGORITHM], options={"verify_aud": False})
        return payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token validation failed")

# -------------------------------------------------------------
# POLICY ENGINE INTEGRATION
# -------------------------------------------------------------
async def authorize(subject: str, action: str, resource: str):
    """Raise HTTP 403 if Policy Engine denies the request."""
    payload = {"subject": subject, "action": action, "resource": resource}
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.post(POLICY_ENGINE_URL, json=payload)
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"Policy Engine unreachable: {exc}")

    if resp.status_code == 200:
        return  # allowed
    if resp.status_code == 403:
        detail = resp.json().get("detail", "Forbidden by policy")
        raise HTTPException(status_code=403, detail=detail)
    raise HTTPException(status_code=500, detail="Unexpected Policy Engine response")

# -------------------------------------------------------------
# CRUD ENDPOINTS WITH POLICY CHECKS
# -------------------------------------------------------------
@app.post("/profiles", response_model=ProfileOut, status_code=status.HTTP_201_CREATED)
async def create_profile(body: ProfileIn, db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)):
    await authorize(subject=f"user:{user_id}", action="create", resource=f"profile:{user_id}")
    if db.get(ProfileORM, user_id):
        raise HTTPException(status_code=409, detail="Profile already exists")
    profile = ProfileORM(user_id=user_id, **body.dict(exclude_unset=True))
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile

@app.get("/profiles/me", response_model=ProfileOut)
async def read_profile(db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)):
    await authorize(subject=f"user:{user_id}", action="read", resource=f"profile:{user_id}")
    profile = db.get(ProfileORM, user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile

@app.patch("/profiles/me", response_model=ProfileOut)
async def update_profile(body: ProfileIn, db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)):
    await authorize(subject=f"user:{user_id}", action="update", resource=f"profile:{user_id}")
    profile = db.get(ProfileORM, user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    for k, v in body.dict(exclude_unset=True).items():
        setattr(profile, k, v)
    profile.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(profile)
    return profile

@app.delete("/profiles/me", status_code=status.HTTP_204_NO_CONTENT)
async def delete_profile(db: Session = Depends(get_db), user_id: str = Depends(get_current_user_id)):
    await authorize(subject=f"user:{user_id}", action="delete", resource=f"profile:{user_id}")
    profile = db.get(ProfileORM, user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    db.delete(profile)
    db.commit()
    return

# ---------------- Admin Endpoints ----------------
@app.get("/profiles/{target_id}", response_model=ProfileOut, tags=["admin"])
async def admin_get_profile(target_id: str, db: Session = Depends(get_db), caller_id: str = Depends(get_current_user_id)):
    await authorize(subject=f"user:{caller_id}", action="read", resource=f"profile:{target_id}")
    profile = db.get(ProfileORM, target_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile

@app.delete("/profiles/{target_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["admin"])
async def admin_delete_profile(target_id: str, db: Session = Depends(get_db), caller_id: str = Depends(get_current_user_id)):
    await authorize(subject=f"user:{caller_id}", action="delete", resource=f"profile:{target_id}")
    profile = db.get(ProfileORM, target_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    db.delete(profile)
    db.commit()
    return

# -------------------------------------------------------------
# STARTUP: ensure table exists (dev only)
# -------------------------------------------------------------
@app.on_event("startup")
def create_tables():
    Base.metadata.create_all(bind=engine)
