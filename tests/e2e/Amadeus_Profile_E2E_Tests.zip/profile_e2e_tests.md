
# Amadeus Profile Service – End‑to‑End Test Scripts

This package contains:

| File | Purpose |
|------|---------|
| **Amadeus_Profile_E2E.postman_collection.json** | Ready‑to‑run Postman v2.1 collection |
| **profile_e2e_tests.md** | Step‑by‑step instructions & curl snippets |

Import the collection, set the environment variables, and run.  
Use **Newman** in CI:

```bash
newman run Amadeus_Profile_E2E.postman_collection.json \
       --env-vars base_url=http://localhost:8000 \
       --env-vars student_email=alice@example.com,student_password=pass \
       --env-vars admin_email=admin@example.com,admin_password=pass \
       --env-vars other_user_id={uuid}
```
