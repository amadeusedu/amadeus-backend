
import request from 'supertest';
import axios from 'axios';
import { newDb } from 'pg-mem';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

// pg-mem setup
const db = newDb();
db.public.none("
  CREATE TABLE threads (
    id uuid primary key, user_id uuid, course_id uuid,
    title varchar, body text, status varchar,
    created_at timestamptz, updated_at timestamptz
  );
  CREATE TABLE posts (
    id uuid primary key, thread_id uuid, parent_post_id uuid,
    user_id uuid, body text, status varchar,
    created_at timestamptz, updated_at timestamptz
  );
  CREATE TABLE moderation_flags (
    id uuid primary key, post_id uuid, flagged_by uuid, reason text,
    action varchar, resolved boolean, created_at timestamptz
  );
");

jest.mock('pg', () => {
  const actual = jest.requireActual('pg');
  return {
    ...actual,
    Pool: function () {
      return new (db.adapters.createPg().Pool)();
    }
  };
});

const app = require('../src/index').default || require('../src/index');

describe('Forum CRUD & moderation', () => {
  let threadId: string;
  let postId: string;

  it('creates a thread', async () => {
    const res = await request(app)
      .post('/threads')
      .send({ user_id: 'user1', title: 'Hi', body: 'first post' })
      .expect(201);
    threadId = res.body.id;
    expect(threadId).toBeDefined();
  });

  it('adds a reply', async () => {
    const res = await request(app)
      .post(`/threads/${threadId}/reply`)
      .send({ user_id: 'user2', body: 'reply' })
      .expect(201);
    postId = res.body.id;
    expect(postId).toBeDefined();
  });

  it('flags a post and triggers moderator alert', async () => {
    mockedAxios.post.mockResolvedValue({ status: 202, data: { sent: 1 } });

    const res = await request(app)
      .patch(`/posts/${postId}/flag`)
      .send({ flagged_by: 'user3', reason: 'spam' })
      .expect(200);

    expect(res.body.flag_id).toBeDefined();
    expect(mockedAxios.post).toHaveBeenCalled();
  });
});
