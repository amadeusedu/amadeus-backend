
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { Readable } from "stream";
import mjml2html from "mjml";

const {
  EMAIL_TEMPLATE_BUCKET = "amadeus-email-templates",
  AWS_REGION = "ap-southeast-2"
} = process.env;

const s3 = new S3Client({ region: AWS_REGION });

/** stream to string helper */
async function streamToString(stream: Readable): Promise<string> {
  const chunks: any[] = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf-8");
}

/** Replace {{var}} placeholders */
function interpolate(template: string, vars: Record<string, string>) {
  return template.replace(/{{\s*([\w]+)\s*}}/g, (_, key) => vars[key] ?? "");
}

export async function renderEmailTemplate(
  templateId: string,
  vars: Record<string, string>
): Promise<{ subject: string; html: string }> {
  const key = `templates/${templateId}.mjml`;

  const obj = await s3.send(
    new GetObjectCommand({
      Bucket: EMAIL_TEMPLATE_BUCKET,
      Key: key
    })
  );

  const templateMjml = await streamToString(obj.Body as Readable);

  // Assume subject is stored in first line comment, e.g. <!-- Subject: Welcome {{name}} -->
  const subjectMatch = templateMjml.match(/<!--\s*Subject:\s*(.*?)\s*-->/i);
  let subject = subjectMatch ? subjectMatch[1].trim() : "Amadeus Notification";

  subject = interpolate(subject, vars);

  const mjmlInterpolated = interpolate(templateMjml, vars);
  const { html } = mjml2html(mjmlInterpolated, {});

  return { subject, html };
}
