
import request from 'supertest';
import { Pool } from 'pg';
import Redis from 'ioredis-mock';
import { newDb } from 'pg-mem';
import * as templateEngine from '../src/templateEngine';
import { renderEmailTemplate } from '../src/templateEngine';

jest.mock('ioredis', () => require('ioredis-mock'));
jest.mock('@aws-sdk/client-ses', () => ({
  SESClient: function () { return {}; },
  SendEmailCommand: function () {}
}));
jest.mock('@sendgrid/mail', () => ({
  setApiKey: jest.fn(),
  send: jest.fn().mockResolvedValue({})
}));

// Mock template rendering
jest.spyOn(templateEngine, 'renderEmailTemplate').mockResolvedValue({
  subject: 'Hello',
  html: '<p>Hello</p>'
} as any);

// Use pg-mem for DB
const db = newDb();
db.public.none("
  CREATE TABLE notifications (
    id uuid primary key,
    user_id uuid,
    type varchar,
    channel varchar,
    title varchar,
    body text,
    status varchar,
    metadata jsonb,
    created_at timestamptz,
    sent_at timestamptz,
    read_at timestamptz
  );
");

// Override Pool to use pg-mem
jest.mock('pg', () => {
  const actual = jest.requireActual('pg');
  return {
    ...actual,
    Pool: function () {
      return new (db.adapters.createPg().Pool)();
    }
  };
});

// Import app AFTER mocks
const app = require('../src/index').default || require('../src/index');

describe('Notification flow', () => {
  it('creates notification and pushes email job', async () => {
    const redis = new Redis();
    (global as any).redis = redis; // hack to share mock instance

    const res = await request(app)
      .post('/notifications')
      .send({
        user_id: '00000000-0000-0000-0000-000000000001',
        type: 'TEST',
        channel: 'EMAIL',
        title: 'Test',
        body: 'Hello'
      })
      .expect(201);

    const job = await redis.rpop('email_queue');
    expect(job).not.toBeNull();
    const jobObj = JSON.parse(job as string);
    expect(jobObj.subject).toBe('Test');
    expect(res.body.status).toBe('QUEUED');
  });
});
