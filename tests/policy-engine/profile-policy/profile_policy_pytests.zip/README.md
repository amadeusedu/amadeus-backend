
# Unit & Integration Tests for Profile Service and Policy Engine

## Quick run

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
pytest -v tests
```

## What is covered

* **Policy Engine**
  * `test_allow_rule` – verifies explicit ALLOW rule
  * `test_default_deny` – verifies default DENY behavior

* **Profile Service**
  * `test_create_and_read_profile` – end‑to‑end check: JWT auth, policy check, profile CRUD

The tests use an in‑memory SQLite DB for speed and run the FastAPI apps via `TestClient`.
