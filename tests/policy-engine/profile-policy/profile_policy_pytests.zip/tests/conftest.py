
import os, asyncio, pytest, uuid
from fastapi.testclient import TestClient

# import the services
import sys
sys.path.append('../profile_service')
sys.path.append('../policy_engine_service')

from policy_engine_service.main import app as policy_app, Base as PolicyBase, engine as policy_engine, SessionLocal as PolicySession
from profile_service.main import app as profile_app, Base as ProfileBase, engine as profile_engine, SessionLocal as ProfileSession

# Use SQLite in-memory for faster tests
os.environ['DATABASE_URL'] = 'sqlite:///./test.db'
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

test_engine = create_engine('sqlite:///./test.db', connect_args={'check_same_thread': False})
TestingSessionLocal = sessionmaker(bind=test_engine, autocommit=False, autoflush=False)

# Recreate tables
PolicyBase.metadata.create_all(bind=test_engine)
ProfileBase.metadata.create_all(bind=test_engine)

@pytest.fixture(scope='session')
def policy_client():
    with TestClient(policy_app) as c:
        yield c

@pytest.fixture(scope='session')
def profile_client():
    with TestClient(profile_app) as c:
        yield c
