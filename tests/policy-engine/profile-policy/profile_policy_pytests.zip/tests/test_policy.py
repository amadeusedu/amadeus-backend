
def test_allow_rule(policy_client):
    # Insert an allow rule directly
    import uuid, json
    from policy_engine_service.main import PolicyORM, PolicySession
    session = PolicySession()
    rule = PolicyORM(id=str(uuid.uuid4()), subject='user:123', action='read', resource='profile:123', effect='ALLOW', priority=1)
    session.add(rule); session.commit()
    resp = policy_client.post('/policy/decide', json={'subject':'user:123','action':'read','resource':'profile:123'})
    assert resp.status_code == 200
    assert resp.json()['allow'] is True

def test_default_deny(policy_client):
    resp = policy_client.post('/policy/decide', json={'subject':'user:123','action':'delete','resource':'profile:456'})
    assert resp.status_code == 403
