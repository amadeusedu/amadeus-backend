
import jwt, datetime

SECRET = 'testsecret'

def create_jwt(uid):
    payload = {'sub': uid, 'exp': datetime.datetime.utcnow()+datetime.timedelta(minutes=5)}
    return jwt.encode(payload, SECRET, algorithm='HS256')

def test_create_and_read_profile(profile_client, policy_client):
    uid = 'user-abc'
    token = create_jwt(uid)
    # Seed owner allow rule
    policy_client.post('/policy/decide')  # no-op just to ensure app running
    # Create profile
    resp = profile_client.post('/profiles', json={'full_name':'Test'}, headers={'Authorization': f'Bearer {token}'})
    assert resp.status_code == 201
    # Read own profile
    resp2 = profile_client.get('/profiles/me', headers={'Authorization': f'Bearer {token}'})
    assert resp2.status_code == 200
    assert resp2.json()['user_id'] == uid
