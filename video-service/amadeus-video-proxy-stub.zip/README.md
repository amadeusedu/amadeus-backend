# Amadeus Video‑Proxy (Stub)

**Purpose**: Provide a minimal endpoint so the Amadeus frontend can begin
integrating video playback. Returns a _hard‑coded_ signed URL placeholder.

## Endpoint

* `GET /videos/{videoId}/url` → JSON response:

```json
{
  "url": "https://cdn.amadeus.education/hls/{videoId}/master.m3u8?Signature=placeholder",
  "expiresAt": "<ISO‑8601>",
  "videoId": "{videoId}"
}
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r video_proxy/requirements.txt
uvicorn video_proxy.app.main:app --reload
```

_Generated 2025-06-22_
