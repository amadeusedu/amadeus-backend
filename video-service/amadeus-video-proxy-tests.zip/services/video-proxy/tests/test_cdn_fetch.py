import types, sys
from unittest import mock
import httpx
from services.video_proxy.app.main import app
from fastapi.testclient import TestClient

# Mock boto3 again
def _mock_boto3_client(*args, **kwargs):
    class MockS3:
        def generate_presigned_url(self, ClientMethod, Params, ExpiresIn):
            return f"https://d111111abcdef8.cloudfront.net/{Params['Key']}"
    return MockS3()

sys.modules["boto3"] = types.ModuleType("boto3")
sys.modules["boto3"].client = _mock_boto3_client

client = TestClient(app)

def test_cdn_fetch_mock():
    # Patch httpx.get so we don't hit network
    with mock.patch.object(httpx, "get", return_value=types.SimpleNamespace(status_code=200)):
        resp = client.get("/videos/84b5a2e1-dc12-4b4d-9c2d-123456789abc/url")
        assert resp.status_code == 200
        url = resp.json()["url"]

        # Simulated CDN fetch
        r = httpx.get(url)
        assert r.status_code == 200
