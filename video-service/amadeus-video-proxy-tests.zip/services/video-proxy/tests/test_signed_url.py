import re, sys, types
from fastapi.testclient import TestClient

# ---- Mock boto3 presign ----------------------------------------------
def _mock_boto3_client(*args, **kwargs):
    class MockS3:
        def generate_presigned_url(self, ClientMethod, Params, ExpiresIn):
            # simulate AWS signature V4 format minimally
            key = Params["Key"]
            return f"https://amadeus-dev-video.s3.amazonaws.com/{key}?X-Amz-Expires={ExpiresIn}&X-Amz-Signature=deadbeef"
    return MockS3()

sys.modules["boto3"] = types.ModuleType("boto3")
sys.modules["boto3"].client = _mock_boto3_client

from services.video_proxy.app.main import app

client = TestClient(app)

def test_signed_url_format_and_expiry():
    resp = client.get("/videos/00112233-4455-6677-8899-aabbccddeeff/url?quality=720p")
    assert resp.status_code == 200
    data = resp.json()

    # regex check
    assert re.match(r"https://amadeus-dev-video\.s3\.amazonaws\.com/.+X-Amz-Signature=", data["url"])

    # expiry param should match default (3600)
    assert "X-Amz-Expires=3600" in data["url"]

    # ensure videoId round‑trips
    assert data["videoId"].startswith("00112233")
