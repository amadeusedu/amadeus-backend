"""Stub routes for Video‑Proxy"""
from fastapi import APIRouter, Path
from datetime import datetime, timedelta, timezone
from .schemas import SignedUrl

router = APIRouter(tags=["videos"])

@router.get("/{video_id}/url", response_model=SignedUrl)
def get_signed_url(video_id: str = Path(..., description="Video identifier")) -> SignedUrl:
    """Return a hard‑coded signed URL (placeholder)."""
    url = f"https://cdn.amadeus.education/hls/{video_id}/master.m3u8?Signature=placeholder"
    expiry = datetime.now(tz=timezone.utc) + timedelta(hours=1)
    return SignedUrl(url=url, expiresAt=expiry, videoId=video_id)
