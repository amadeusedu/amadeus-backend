from pydantic import BaseModel
from datetime import datetime

class SignedUrl(BaseModel):
    url: str
    expiresAt: datetime
    videoId: str
