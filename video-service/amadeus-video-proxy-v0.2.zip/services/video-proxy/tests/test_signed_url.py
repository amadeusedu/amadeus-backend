import types, sys
from fastapi.testclient import TestClient

# --- Mock boto3 ---------------------------------------------------------
def _mock_boto3_client(*args, **kwargs):
    class MockS3:
        def generate_presigned_url(self, ClientMethod, Params, ExpiresIn):
            return f"https://mock-s3/{Params['Key']}?exp={ExpiresIn}"
    return MockS3()

sys.modules['boto3'] = types.ModuleType('boto3')
sys.modules['boto3'].client = _mock_boto3_client

from services.video_proxy.app.main import app

client = TestClient(app)

def test_signed_url():
    res = client.get("/videos/123e4567-e89b-12d3-a456-426614174000/url")
    assert res.status_code == 200
    data = res.json()
    assert data["url"].startswith("https://mock-s3/")
    assert data["videoId"].startswith("123e4567")
